package com.ecommerce.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecommerce.app.dto.OrderResponse;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.UserRepository;

@Service
public class AdminService {

    private final UserRepository userRepository;
    private final OrderService orderService;

    public AdminService(UserRepository userRepository, OrderService orderService) {
        this.userRepository = userRepository;
        this.orderService = orderService;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<OrderResponse> getAllOrders() {
        return orderService.getAllOrders();
    }
}
