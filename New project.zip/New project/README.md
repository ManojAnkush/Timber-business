# E-commerce Spring Boot Project

This project is a Maven-based Spring Boot e-commerce starter with JWT authentication, OTP verification, product management, cart, orders, payments, admin APIs, a static frontend, and AWS deployment guidance.

## Tech Stack

- Java 17
- Spring Boot
- Spring Web
- Spring Data JPA
- MySQL Driver
- Spring Security
- Lombok
- JWT (`jjwt`)
- HTML, CSS, JavaScript frontend

## Project Structure

```text
src/
  main/
    java/com/ecommerce/app/
      config/
      controller/
      dto/
      entity/
      repository/
      service/
      EcommerceApplication.java
    resources/
      application.properties
      static/
        index.html
        product.html
        cart.html
        auth.html
        checkout.html
        admin.html
        css/styles.css
        js/app.js
```

## Features Implemented

### Authentication and Security

- JWT-based stateless authentication
- BCrypt password encryption
- Role-based access with `ADMIN` and `USER`
- OTP generation during registration
- OTP verification before account activation
- Mock email sending for OTP delivery
- Default admin bootstrap account:
  - Email: `admin@ecommerce.com`
  - Password: `Admin@123`

### Product Module

- Public product listing
- Admin-only create, update, delete
- Product fields:
  - `id`
  - `name`
  - `description`
  - `price`
  - `imageUrl`
  - `stock`

### Cart Module

- Add product to cart
- Update cart quantity
- Remove cart item
- View current user cart

### Order Module

- Place order from cart
- View user order history
- Order status values:
  - `PENDING`
  - `SHIPPED`
  - `DELIVERED`

### Payment Module

- Mock payment integration
- Supports simulated success and failure
- Mock provider names such as `MOCK_STRIPE` and `MOCK_RAZORPAY`

### Admin Module

- View all users
- View all orders
- Update order status

### Frontend Pages

- Home
- Product details
- Cart
- Login/Register with OTP flow
- Checkout
- Admin dashboard

## MySQL Configuration

The backend is configured in [application.properties](/C:/Users/Admin/Documents/New%20project/src/main/resources/application.properties).

Default local connection:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecommerce_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

Update the username and password before running locally.

## API Summary

### Auth APIs

- `POST /api/auth/register`
- `POST /api/auth/sendOtp`
- `POST /api/auth/verifyOtp`
- `POST /api/auth/resendOtp`
- `POST /api/auth/login`

### Product APIs

- `GET /api/products`
- `GET /api/products/{id}`
- `POST /api/products` (`ADMIN`)
- `PUT /api/products/{id}` (`ADMIN`)
- `DELETE /api/products/{id}` (`ADMIN`)

### Cart APIs

- `GET /api/cart`
- `POST /api/cart`
- `PUT /api/cart/{cartItemId}?quantity=2`
- `DELETE /api/cart/{cartItemId}`

### Order APIs

- `POST /api/orders`
- `GET /api/orders`

### Payment APIs

- `POST /api/payments`

### Admin APIs

- `GET /api/admin/users`
- `GET /api/admin/orders`
- `PUT /api/admin/orders/{orderId}/status`

## OTP Flow Explanation

1. Client calls `POST /api/auth/sendOtp` or `POST /api/auth/register` with `name`, `email`, `password`, and `role`.
2. Backend generates a 6-digit OTP and stores the pending registration temporarily in memory.
3. OTP is returned through the mock email service and logged by the backend for development use.
4. Client submits `email` and `otp` to `POST /api/auth/verifyOtp`.
5. Backend activates the account and returns a JWT token.

Note: OTP storage is currently in-memory for simplicity. For production, store OTPs in Redis or a database with expiration handling.

## Payment Flow Explanation

1. User places an order from the cart using `POST /api/orders`.
2. Client sends `orderId`, `provider`, and `success` to `POST /api/payments`.
3. Backend creates a mock payment record and marks it as `SUCCESS` or `FAILURE`.

For production, replace `PaymentService` with real Stripe or Razorpay SDK integration and webhook verification.

## Run Locally

### Prerequisites

- Java 17 installed
- Maven installed and available as `mvn`
- MySQL running locally

### Commands

```bash
mvn spring-boot:run
```

Or:

```bash
mvn clean package
java -jar target/ecommerce-app-0.0.1-SNAPSHOT.jar
```

Then open:

- [http://localhost:8080](http://localhost:8080)

## AWS Deployment Guide

### Architecture

- Backend: AWS EC2
- Database: AWS RDS MySQL
- Images: AWS S3

### 1. Launch EC2 Instance

1. Open AWS Console.
2. Launch an EC2 instance with Amazon Linux 2023 or Ubuntu.
3. Allow inbound rules:
   - `22` for SSH
   - `8080` for the Spring Boot app
   - `80` if using Nginx reverse proxy
4. Download the PEM key.

### 2. Connect to EC2

For Amazon Linux:

```bash
ssh -i your-key.pem ec2-user@YOUR_EC2_PUBLIC_IP
```

For Ubuntu:

```bash
ssh -i your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
```

### 3. Install Java and Maven

Amazon Linux:

```bash
sudo dnf update -y
sudo dnf install java-17-amazon-corretto-devel maven -y
```

Ubuntu:

```bash
sudo apt update
sudo apt install openjdk-17-jdk maven -y
```

### 4. Create RDS MySQL

1. Open RDS in AWS Console.
2. Create a MySQL instance.
3. Choose username, password, DB name.
4. Ensure the EC2 security group can access the RDS port `3306`.

Example RDS config for `application.properties`:

```properties
spring.datasource.url=jdbc:mysql://your-rds-endpoint:3306/ecommerce_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=admin
spring.datasource.password=your_rds_password
```

### 5. Upload Project to EC2

Option A: Clone from Git:

```bash
git clone <your-repository-url>
cd ecommerce-app
```

Option B: Copy project from local machine:

```bash
scp -i your-key.pem -r ecommerce-app ec2-user@YOUR_EC2_PUBLIC_IP:/home/ec2-user/
```

### 6. Build the Application

```bash
cd ecommerce-app
mvn clean package -DskipTests
```

### 7. Run the Spring Boot Jar

```bash
java -jar target/ecommerce-app-0.0.1-SNAPSHOT.jar
```

Run it in the background:

```bash
nohup java -jar target/ecommerce-app-0.0.1-SNAPSHOT.jar > app.log 2>&1 &
```

### 8. Optional: Use Nginx Reverse Proxy

Install Nginx:

```bash
sudo dnf install nginx -y
sudo systemctl enable nginx
sudo systemctl start nginx
```

Example Nginx config:

```nginx
server {
    listen 80;
    server_name your-domain-or-ec2-ip;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Reload Nginx:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

### 9. Store Images in S3

1. Create an S3 bucket.
2. Grant the EC2 instance access through an IAM role.
3. Upload product images to the bucket.
4. Save the resulting S3 object URLs into the `imageUrl` field of each product.

Production improvement:

- Replace manual URLs with a dedicated image upload API using the AWS SDK for Java.

### 10. Production Environment Variables

Instead of hardcoding secrets, set them with environment variables or a secrets manager.

Example:

```bash
export SPRING_DATASOURCE_URL=jdbc:mysql://your-rds-endpoint:3306/ecommerce_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
export SPRING_DATASOURCE_USERNAME=admin
export SPRING_DATASOURCE_PASSWORD=your_rds_password
export APP_JWT_SECRET=your_very_strong_secret
```

Then map them in `application.properties` if you want:

```properties
spring.datasource.url=${SPRING_DATASOURCE_URL}
spring.datasource.username=${SPRING_DATASOURCE_USERNAME}
spring.datasource.password=${SPRING_DATASOURCE_PASSWORD}
app.jwt.secret=${APP_JWT_SECRET}
```

### 11. Recommended Production Hardening

- Use HTTPS with ACM and an Application Load Balancer or Nginx with TLS.
- Move OTP storage from memory to Redis.
- Add real SMTP or SES for email delivery.
- Use Stripe or Razorpay server SDKs plus webhook verification.
- Add unit and integration tests.
- Add CloudWatch logging and health checks.
- Serve frontend via CloudFront or S3 if you later split it from the backend.

## Notes

- OTP storage is temporary and resets when the app restarts.
- Payment integration is mocked.
- The frontend is intentionally lightweight and designed for starter-project use.
- This workspace did not have Maven installed, so the project could not be compiled in-place here.
