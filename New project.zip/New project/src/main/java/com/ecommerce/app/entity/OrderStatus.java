package com.ecommerce.app.entity;

public enum OrderStatus {
    PENDING,
    SHIPPED,
    DELIVERED
}
