package com.ecommerce.app.dto;

import java.math.BigDecimal;

import com.ecommerce.app.entity.PaymentStatus;

public class PaymentResponse {

    private Long paymentId;
    private Long orderId;
    private String provider;
    private String transactionId;
    private BigDecimal amount;
    private PaymentStatus status;
    private String message;

    public PaymentResponse() {
    }

    public PaymentResponse(Long paymentId, Long orderId, String provider, String transactionId,
                           BigDecimal amount, PaymentStatus status, String message) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.provider = provider;
        this.transactionId = transactionId;
        this.amount = amount;
        this.status = status;
        this.message = message;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public String getProvider() {
        return provider;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public static class Builder {
        private Long paymentId;
        private Long orderId;
        private String provider;
        private String transactionId;
        private BigDecimal amount;
        private PaymentStatus status;
        private String message;

        public Builder paymentId(Long paymentId) {
            this.paymentId = paymentId;
            return this;
        }

        public Builder orderId(Long orderId) {
            this.orderId = orderId;
            return this;
        }

        public Builder provider(String provider) {
            this.provider = provider;
            return this;
        }

        public Builder transactionId(String transactionId) {
            this.transactionId = transactionId;
            return this;
        }

        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        public Builder status(PaymentStatus status) {
            this.status = status;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public PaymentResponse build() {
            return new PaymentResponse(paymentId, orderId, provider, transactionId, amount, status, message);
        }
    }
}
