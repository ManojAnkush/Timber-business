package com.ecommerce.app.dto;

import java.math.BigDecimal;
import java.util.List;

public class CartSummaryResponse {

    private List<CartItemResponse> items;
    private BigDecimal totalAmount;

    public CartSummaryResponse() {
    }

    public CartSummaryResponse(List<CartItemResponse> items, BigDecimal totalAmount) {
        this.items = items;
        this.totalAmount = totalAmount;
    }

    public static Builder builder() {
        return new Builder();
    }

    public List<CartItemResponse> getItems() {
        return items;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public static class Builder {
        private List<CartItemResponse> items;
        private BigDecimal totalAmount;

        public Builder items(List<CartItemResponse> items) {
            this.items = items;
            return this;
        }

        public Builder totalAmount(BigDecimal totalAmount) {
            this.totalAmount = totalAmount;
            return this;
        }

        public CartSummaryResponse build() {
            return new CartSummaryResponse(items, totalAmount);
        }
    }
}
