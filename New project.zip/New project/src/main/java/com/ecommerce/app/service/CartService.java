package com.ecommerce.app.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ecommerce.app.dto.CartItemResponse;
import com.ecommerce.app.dto.CartRequest;
import com.ecommerce.app.dto.CartSummaryResponse;
import com.ecommerce.app.entity.Cart;
import com.ecommerce.app.entity.Product;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.CartRepository;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final ProductService productService;
    private final UserService userService;

    public CartService(CartRepository cartRepository, ProductService productService, UserService userService) {
        this.cartRepository = cartRepository;
        this.productService = productService;
        this.userService = userService;
    }

    public CartSummaryResponse getMyCart() {
        User user = userService.getCurrentUser();
        return buildCartSummary(user);
    }

    public CartSummaryResponse addToCart(CartRequest request) {
        User user = userService.getCurrentUser();
        Product product = productService.getProductEntity(request.getProductId());
        validateStock(product, request.getQuantity());

        Cart cartItem = cartRepository.findByUserAndProduct(user, product)
                .orElse(Cart.builder().user(user).product(product).quantity(0).build());

        int newQuantity = cartItem.getQuantity() + request.getQuantity();
        validateStock(product, newQuantity);
        cartItem.setQuantity(newQuantity);
        cartRepository.save(cartItem);
        return buildCartSummary(user);
    }

    public CartSummaryResponse updateQuantity(Long cartItemId, Integer quantity) {
        User user = userService.getCurrentUser();
        Cart cartItem = getCartItem(cartItemId, user);
        validateStock(cartItem.getProduct(), quantity);
        cartItem.setQuantity(quantity);
        cartRepository.save(cartItem);
        return buildCartSummary(user);
    }

    public CartSummaryResponse removeFromCart(Long cartItemId) {
        User user = userService.getCurrentUser();
        Cart cartItem = getCartItem(cartItemId, user);
        cartRepository.delete(cartItem);
        return buildCartSummary(user);
    }

    public List<Cart> getUserCartItems(User user) {
        return cartRepository.findByUser(user);
    }

    public void clearCart(User user) {
        cartRepository.deleteByUser(user);
    }

    private Cart getCartItem(Long cartItemId, User user) {
        Cart cartItem = cartRepository.findById(cartItemId)
                .orElseThrow(() -> new IllegalArgumentException("Cart item not found"));
        if (!cartItem.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Cart item does not belong to user");
        }
        return cartItem;
    }

    private void validateStock(Product product, Integer quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }
        if (product.getStock() == null || product.getStock() < quantity) {
            throw new IllegalArgumentException("Insufficient stock available");
        }
    }

    private CartSummaryResponse buildCartSummary(User user) {
        List<CartItemResponse> items = cartRepository.findByUser(user).stream()
                .map(item -> CartItemResponse.builder()
                        .cartItemId(item.getId())
                        .productId(item.getProduct().getId())
                        .productName(item.getProduct().getName())
                        .imageUrl(item.getProduct().getImageUrl())
                        .quantity(item.getQuantity())
                        .unitPrice(item.getProduct().getPrice())
                        .lineTotal(item.getProduct().getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                        .build())
                .toList();

        BigDecimal total = items.stream()
                .map(CartItemResponse::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return CartSummaryResponse.builder()
                .items(items)
                .totalAmount(total)
                .build();
    }
}
