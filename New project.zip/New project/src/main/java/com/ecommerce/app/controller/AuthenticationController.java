package com.ecommerce.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.app.dto.ApiResponse;
import com.ecommerce.app.dto.LoginRequest;
import com.ecommerce.app.dto.OtpRequest;
import com.ecommerce.app.dto.OtpVerificationRequest;
import com.ecommerce.app.dto.RegisterRequest;
import com.ecommerce.app.service.AuthService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

    private final AuthService authService;

    public AuthenticationController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Registration started. Verify OTP to activate account.")
                .data(authService.sendOtp(request))
                .build());
    }

    @PostMapping("/sendOtp")
    public ResponseEntity<ApiResponse> sendOtp(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("OTP generated")
                .data(authService.sendOtp(request))
                .build());
    }

    @PostMapping("/verifyOtp")
    public ResponseEntity<ApiResponse> verifyOtp(@Valid @RequestBody OtpVerificationRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("OTP verified")
                .data(authService.verifyOtp(request))
                .build());
    }

    @PostMapping("/resendOtp")
    public ResponseEntity<ApiResponse> resendOtp(@Valid @RequestBody OtpRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message(authService.resendOtp(request.getEmail()))
                .build());
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Login successful")
                .data(authService.login(request))
                .build());
    }
}
