const state = {
    token: localStorage.getItem("token"),
    role: localStorage.getItem("role"),
    email: localStorage.getItem("email")
};

const toastEl = document.getElementById("toast");

function showToast(message) {
    if (!toastEl) {
        return;
    }
    toastEl.textContent = message;
    toastEl.classList.add("show");
    setTimeout(() => toastEl.classList.remove("show"), 2500);
}

async function api(path, options = {}) {
    const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
    };

    if (state.token) {
        headers.Authorization = `Bearer ${state.token}`;
    }

    const response = await fetch(path, { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.success === false) {
        throw new Error(data.message || "Request failed");
    }
    return data;
}

function updateAuthLink() {
    const authLink = document.getElementById("authLink");
    if (authLink && state.token) {
        authLink.textContent = `Signed in as ${state.email || "user"}`;
        authLink.href = "/auth.html";
    }
}

function currency(value) {
    return `Rs. ${Number(value || 0).toFixed(2)}`;
}

function renderProductCard(product) {
    return `
        <article class="product-card">
            <img src="${product.imageUrl || "https://via.placeholder.com/400x300?text=Product"}" alt="${product.name}">
            <div class="product-meta">
                <h3>${product.name}</h3>
                <span>${product.stock} in stock</span>
            </div>
            <p class="muted">${product.description || "No description available."}</p>
            <p class="price">${currency(product.price)}</p>
            <div class="product-meta">
                <a class="ghost-btn" href="/product.html?id=${product.id}">View</a>
                <button onclick="quickAddToCart(${product.id})">Add To Cart</button>
            </div>
        </article>
    `;
}

async function loadProducts() {
    const grid = document.getElementById("productGrid");
    if (!grid) {
        return;
    }
    const response = await api("/api/products");
    grid.innerHTML = response.data.map(renderProductCard).join("");
}

async function quickAddToCart(productId, quantity = 1) {
    try {
        await api("/api/cart", {
            method: "POST",
            body: JSON.stringify({ productId, quantity })
        });
        showToast("Added to cart");
    } catch (error) {
        showToast(error.message);
    }
}

async function loadProductDetails() {
    const container = document.getElementById("productDetails");
    if (!container) {
        return;
    }

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (!id) {
        container.innerHTML = "<p>Product not found.</p>";
        return;
    }

    const response = await api(`/api/products/${id}`);
    const product = response.data;
    container.innerHTML = `
        <img src="${product.imageUrl || "https://via.placeholder.com/500x360?text=Product"}" alt="${product.name}">
        <div>
            <p class="eyebrow">Product Detail</p>
            <h1>${product.name}</h1>
            <p class="muted">${product.description || "No description available."}</p>
            <p class="price">${currency(product.price)}</p>
            <p>${product.stock} items left in stock</p>
        </div>
    `;

    const addBtn = document.getElementById("detailAddToCart");
    addBtn?.addEventListener("click", () => {
        const quantity = Number(document.getElementById("detailQuantity").value || 1);
        quickAddToCart(product.id, quantity);
    });
}

async function loadCart() {
    const container = document.getElementById("cartItems");
    const totalEl = document.getElementById("cartTotal");
    if (!container || !totalEl) {
        return;
    }

    try {
        const response = await api("/api/cart");
        const cart = response.data;
        totalEl.textContent = currency(cart.totalAmount);
        if (!cart.items.length) {
            container.innerHTML = "<p class='card'>Your cart is empty.</p>";
            return;
        }
        container.innerHTML = cart.items.map(item => `
            <article class="cart-item">
                <img class="cart-thumb" src="${item.imageUrl || "https://via.placeholder.com/200x150?text=Item"}" alt="${item.productName}">
                <div>
                    <h3>${item.productName}</h3>
                    <p>${item.quantity} x ${currency(item.unitPrice)}</p>
                    <p class="price">${currency(item.lineTotal)}</p>
                </div>
                <div class="stack">
                    <button class="ghost-btn" onclick="changeCartQty(${item.cartItemId}, ${item.quantity + 1})">+1</button>
                    <button class="ghost-btn" onclick="changeCartQty(${item.cartItemId}, ${Math.max(1, item.quantity - 1)})">-1</button>
                    <button onclick="removeCartItem(${item.cartItemId})">Remove</button>
                </div>
            </article>
        `).join("");
    } catch (error) {
        container.innerHTML = `<p class="card">${error.message}</p>`;
    }
}

async function changeCartQty(cartItemId, quantity) {
    try {
        await api(`/api/cart/${cartItemId}?quantity=${quantity}`, { method: "PUT" });
        showToast("Cart updated");
        loadCart();
    } catch (error) {
        showToast(error.message);
    }
}

async function removeCartItem(cartItemId) {
    try {
        await api(`/api/cart/${cartItemId}`, { method: "DELETE" });
        showToast("Item removed");
        loadCart();
    } catch (error) {
        showToast(error.message);
    }
}

function setupAuthPage() {
    const registerForm = document.getElementById("registerForm");
    const verifyOtpForm = document.getElementById("verifyOtpForm");
    const loginForm = document.getElementById("loginForm");
    const logoutBtn = document.getElementById("logoutBtn");

    registerForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const form = new FormData(registerForm);
        const payload = Object.fromEntries(form.entries());
        try {
            const response = await api("/api/auth/sendOtp", {
                method: "POST",
                body: JSON.stringify(payload)
            });
            showToast(response.data.message || response.message);
        } catch (error) {
            showToast(error.message);
        }
    });

    verifyOtpForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const payload = Object.fromEntries(new FormData(verifyOtpForm).entries());
        try {
            const response = await api("/api/auth/verifyOtp", {
                method: "POST",
                body: JSON.stringify(payload)
            });
            saveSession(response.data);
            showToast("Registration complete");
        } catch (error) {
            showToast(error.message);
        }
    });

    loginForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const payload = Object.fromEntries(new FormData(loginForm).entries());
        try {
            const response = await api("/api/auth/login", {
                method: "POST",
                body: JSON.stringify(payload)
            });
            saveSession(response.data);
            showToast("Logged in");
        } catch (error) {
            showToast(error.message);
        }
    });

    logoutBtn?.addEventListener("click", () => {
        localStorage.clear();
        state.token = null;
        state.role = null;
        state.email = null;
        showToast("Logged out");
        updateAuthLink();
    });
}

function saveSession(data) {
    if (!data?.token) {
        return;
    }
    state.token = data.token;
    state.role = data.role;
    state.email = data.email;
    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);
    localStorage.setItem("email", data.email);
    updateAuthLink();
}

function setupCheckoutPage() {
    const placeOrderBtn = document.getElementById("placeOrderBtn");
    const paymentForm = document.getElementById("paymentForm");

    placeOrderBtn?.addEventListener("click", async () => {
        try {
            const response = await api("/api/orders", { method: "POST" });
            showToast(`Order placed: #${response.data.id}`);
            loadOrders();
        } catch (error) {
            showToast(error.message);
        }
    });

    paymentForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const form = Object.fromEntries(new FormData(paymentForm).entries());
        form.success = form.success === "true";
        form.orderId = Number(form.orderId);
        try {
            const response = await api("/api/payments", {
                method: "POST",
                body: JSON.stringify(form)
            });
            showToast(response.data.message);
        } catch (error) {
            showToast(error.message);
        }
    });
}

async function loadOrders() {
    const container = document.getElementById("orderHistory");
    if (!container) {
        return;
    }
    try {
        const response = await api("/api/orders");
        const orders = response.data;
        container.innerHTML = orders.length
            ? orders.map(order => `
                <article class="card">
                    <strong>Order #${order.id}</strong>
                    <span>Status: ${order.status}</span>
                    <span>Total: ${currency(order.totalAmount)}</span>
                    <span>Created: ${new Date(order.createdAt).toLocaleString()}</span>
                </article>
            `).join("")
            : "<p>No orders placed yet.</p>";
    } catch (error) {
        container.innerHTML = `<p>${error.message}</p>`;
    }
}

function setupAdminPage() {
    const productForm = document.getElementById("productForm");
    const loadUsersBtn = document.getElementById("loadUsersBtn");
    const loadOrdersBtn = document.getElementById("loadOrdersBtn");
    const orderStatusForm = document.getElementById("orderStatusForm");

    productForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const payload = Object.fromEntries(new FormData(productForm).entries());
        payload.price = Number(payload.price);
        payload.stock = Number(payload.stock);
        try {
            await api("/api/products", {
                method: "POST",
                body: JSON.stringify(payload)
            });
            showToast("Product created");
            productForm.reset();
        } catch (error) {
            showToast(error.message);
        }
    });

    loadUsersBtn?.addEventListener("click", async () => {
        const list = document.getElementById("usersList");
        try {
            const response = await api("/api/admin/users");
            list.innerHTML = response.data.map(user => `
                <article class="card">
                    <strong>${user.name}</strong>
                    <span>${user.email}</span>
                    <span>${user.role}</span>
                    <span>${user.enabled ? "Active" : "Pending"}</span>
                </article>
            `).join("");
        } catch (error) {
            showToast(error.message);
        }
    });

    loadOrdersBtn?.addEventListener("click", async () => {
        const list = document.getElementById("adminOrdersList");
        try {
            const response = await api("/api/admin/orders");
            list.innerHTML = response.data.map(order => `
                <article class="card">
                    <strong>Order #${order.id}</strong>
                    <span>Status: ${order.status}</span>
                    <span>Total: ${currency(order.totalAmount)}</span>
                </article>
            `).join("");
        } catch (error) {
            showToast(error.message);
        }
    });

    orderStatusForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const payload = Object.fromEntries(new FormData(orderStatusForm).entries());
        try {
            await api(`/api/admin/orders/${payload.orderId}/status`, {
                method: "PUT",
                body: JSON.stringify({ status: payload.status })
            });
            showToast("Order status updated");
        } catch (error) {
            showToast(error.message);
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    updateAuthLink();
    document.getElementById("refreshProducts")?.addEventListener("click", loadProducts);

    const page = document.body.dataset.page;
    if (page === "home") loadProducts();
    if (page === "product") loadProductDetails();
    if (page === "cart") loadCart();
    if (page === "auth") setupAuthPage();
    if (page === "checkout") {
        setupCheckoutPage();
        loadOrders();
    }
    if (page === "admin") setupAdminPage();
});
