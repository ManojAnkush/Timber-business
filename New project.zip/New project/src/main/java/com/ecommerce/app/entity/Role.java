package com.ecommerce.app.entity;

public enum Role {
    ADMIN,
    USER
}
