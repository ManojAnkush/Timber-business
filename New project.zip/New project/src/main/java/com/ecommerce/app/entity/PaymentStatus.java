package com.ecommerce.app.entity;

public enum PaymentStatus {
    INITIATED,
    SUCCESS,
    FAILURE
}
