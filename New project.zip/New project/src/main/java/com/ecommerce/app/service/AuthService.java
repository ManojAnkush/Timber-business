package com.ecommerce.app.service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ecommerce.app.config.JwtUtil;
import com.ecommerce.app.dto.AuthResponse;
import com.ecommerce.app.dto.LoginRequest;
import com.ecommerce.app.dto.OtpVerificationRequest;
import com.ecommerce.app.dto.RegisterRequest;
import com.ecommerce.app.entity.Role;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.UserRepository;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final EmailService emailService;

    private final Map<String, PendingRegistration> pendingRegistrations = new ConcurrentHashMap<>();

    @Value("${app.otp.expiration-minutes:10}")
    private long otpExpirationMinutes;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager,
                       JwtUtil jwtUtil,
                       EmailService emailService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.emailService = emailService;
    }

    public AuthResponse sendOtp(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("User already exists with this email");
        }

        String otp = generateOtp();
        pendingRegistrations.put(
                request.getEmail(),
                new PendingRegistration(
                        request.getName(),
                        request.getEmail(),
                        passwordEncoder.encode(request.getPassword()),
                        request.getRole() == null ? Role.USER : request.getRole(),
                        otp,
                        LocalDateTime.now().plusMinutes(otpExpirationMinutes)
                )
        );

        String message = emailService.sendOtp(request.getEmail(), otp);
        return AuthResponse.builder()
                .email(request.getEmail())
                .role((request.getRole() == null ? Role.USER : request.getRole()).name())
                .message(message)
                .build();
    }

    public AuthResponse verifyOtp(OtpVerificationRequest request) {
        PendingRegistration pending = pendingRegistrations.get(request.getEmail());
        if (pending == null) {
            throw new IllegalArgumentException("No OTP request found for this email");
        }
        if (pending.getExpiresAt().isBefore(LocalDateTime.now())) {
            pendingRegistrations.remove(request.getEmail());
            throw new IllegalArgumentException("OTP has expired");
        }
        if (!pending.getOtp().equals(request.getOtp())) {
            throw new IllegalArgumentException("Invalid OTP");
        }

        User user = User.builder()
                .name(pending.getName())
                .email(pending.getEmail())
                .password(pending.getPassword())
                .role(pending.getRole())
                .enabled(true)
                .build();
        userRepository.save(user);
        pendingRegistrations.remove(request.getEmail());

        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())
                .build();

        return AuthResponse.builder()
                .token(jwtUtil.generateToken(userDetails, Map.of("role", user.getRole().name(), "name", user.getName())))
                .email(user.getEmail())
                .role(user.getRole().name())
                .message("OTP verified. User account activated.")
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        UserDetails userDetails = org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())
                .build();

        return AuthResponse.builder()
                .token(jwtUtil.generateToken(userDetails, Map.of("role", user.getRole().name(), "name", user.getName())))
                .email(user.getEmail())
                .role(user.getRole().name())
                .message("Login successful")
                .build();
    }

    public String resendOtp(String email) {
        PendingRegistration pending = pendingRegistrations.get(email);
        if (pending == null) {
            throw new IllegalArgumentException("No pending registration found");
        }

        String otp = generateOtp();
        pendingRegistrations.put(email, new PendingRegistration(
                pending.getName(),
                pending.getEmail(),
                pending.getPassword(),
                pending.getRole(),
                otp,
                LocalDateTime.now().plusMinutes(otpExpirationMinutes)
        ));
        return emailService.sendOtp(email, otp);
    }

    private String generateOtp() {
        return String.format("%06d", new Random().nextInt(1_000_000));
    }

    private static class PendingRegistration {
        private final String name;
        private final String email;
        private final String password;
        private final Role role;
        private final String otp;
        private final LocalDateTime expiresAt;

        public PendingRegistration(String name, String email, String password, Role role, String otp, LocalDateTime expiresAt) {
            this.name = name;
            this.email = email;
            this.password = password;
            this.role = role;
            this.otp = otp;
            this.expiresAt = expiresAt;
        }

        public String getName() {
            return name;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }

        public Role getRole() {
            return role;
        }

        public String getOtp() {
            return otp;
        }

        public LocalDateTime getExpiresAt() {
            return expiresAt;
        }
    }
}
