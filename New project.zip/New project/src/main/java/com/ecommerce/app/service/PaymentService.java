package com.ecommerce.app.service;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.ecommerce.app.dto.PaymentRequest;
import com.ecommerce.app.dto.PaymentResponse;
import com.ecommerce.app.entity.Order;
import com.ecommerce.app.entity.Payment;
import com.ecommerce.app.entity.PaymentStatus;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.PaymentRepository;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderService orderService;
    private final UserService userService;

    public PaymentService(PaymentRepository paymentRepository, OrderService orderService, UserService userService) {
        this.paymentRepository = paymentRepository;
        this.orderService = orderService;
        this.userService = userService;
    }

    public PaymentResponse processPayment(PaymentRequest request) {
        Order order = orderService.getOrderEntity(request.getOrderId());
        User currentUser = userService.getCurrentUser();
        if (!order.getUser().getId().equals(currentUser.getId())) {
            throw new IllegalArgumentException("You can only pay for your own orders");
        }

        Payment payment = paymentRepository.findByOrder(order).orElse(
                Payment.builder()
                        .order(order)
                        .createdAt(LocalDateTime.now())
                        .amount(order.getTotalAmount())
                        .build()
        );

        payment.setProvider(request.getProvider());
        payment.setTransactionId(UUID.randomUUID().toString());
        payment.setStatus(request.isSuccess() ? PaymentStatus.SUCCESS : PaymentStatus.FAILURE);
        payment.setMessage(request.isSuccess() ? "Payment completed successfully" : "Payment failed");

        Payment savedPayment = paymentRepository.save(payment);
        return PaymentResponse.builder()
                .paymentId(savedPayment.getId())
                .orderId(order.getId())
                .provider(savedPayment.getProvider())
                .transactionId(savedPayment.getTransactionId())
                .amount(savedPayment.getAmount())
                .status(savedPayment.getStatus())
                .message(savedPayment.getMessage())
                .build();
    }
}
