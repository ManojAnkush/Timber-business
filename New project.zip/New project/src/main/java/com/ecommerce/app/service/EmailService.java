package com.ecommerce.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    @Value("${app.otp.mock-email:true}")
    private boolean mockEmail;

    public String sendOtp(String email, String otp) {
        String message = "OTP sent successfully";
        if (mockEmail) {
            log.info("Mock OTP for {} is {}", email, otp);
            return message + ". Mock OTP: " + otp;
        }

        log.info("Email integration not configured. OTP for {} generated but not sent.", email);
        return message + ". Email integration placeholder in use.";
    }
}
