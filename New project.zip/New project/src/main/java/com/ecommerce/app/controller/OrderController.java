package com.ecommerce.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.app.dto.ApiResponse;
import com.ecommerce.app.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse> placeOrder() {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Order placed successfully")
                .data(orderService.placeOrder())
                .build());
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getOrderHistory() {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Order history fetched successfully")
                .data(orderService.getMyOrders())
                .build());
    }
}
