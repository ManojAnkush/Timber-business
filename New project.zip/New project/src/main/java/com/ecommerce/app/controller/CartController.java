package com.ecommerce.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.app.dto.ApiResponse;
import com.ecommerce.app.dto.CartRequest;
import com.ecommerce.app.service.CartService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getCart() {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Cart fetched successfully")
                .data(cartService.getMyCart())
                .build());
    }

    @PostMapping
    public ResponseEntity<ApiResponse> addToCart(@Valid @RequestBody CartRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Item added to cart")
                .data(cartService.addToCart(request))
                .build());
    }

    @PutMapping("/{cartItemId}")
    public ResponseEntity<ApiResponse> updateCartItem(@PathVariable Long cartItemId, @RequestParam Integer quantity) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Cart updated successfully")
                .data(cartService.updateQuantity(cartItemId, quantity))
                .build());
    }

    @DeleteMapping("/{cartItemId}")
    public ResponseEntity<ApiResponse> removeFromCart(@PathVariable Long cartItemId) {
        return ResponseEntity.ok(ApiResponse.builder()
                .success(true)
                .message("Item removed from cart")
                .data(cartService.removeFromCart(cartItemId))
                .build());
    }
}
